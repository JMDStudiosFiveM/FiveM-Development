fx_version 'cerulean'
game 'gta5'

author 'johns0365'
description 'Vehicle Megaphone System'
version '1.0.0'

shared_script 'config.lua' 

client_scripts {
    'config.lua',
    'client.lua'
}

server_scripts {
    
}