RegisterCommand("photo", function()
    if mainMenu ~= nil then
        mainMenu:Visible(not mainMenu:Visible())
    else
        InitMenu()
        mainMenu:Visible(true)
    end
end, false)

TriggerEvent('chat:addSuggestion', '/photo', 'Open the Freecam Photo Mode menu.')


local freecamActive = false
local camHandle = nil
local camSpeed = 1.0
local camFov = 60.0
local menuFocused = true 
_menuPool = NativeUI.CreatePool()
mainMenu = nil

local filters = {
    {"None", ""},
    {"Cinema", "cinema"},
    {"Noir", "r_noir"},
    {"Sepia", "sepia"},
    {"Vibrant", "nextgen"},
    {"Security", "scanline_cam_BW"}
}


function InitMenu()
    if mainMenu ~= nil then return end
    
    mainMenu = NativeUI.CreateMenu("Photo Mode", "~b~Rockstar Style Editor")
    _menuPool:Add(mainMenu)

    local toggleCam = NativeUI.CreateItem("Toggle Freecam", "Enter/Exit Freecam mode.")
    local speedItem = NativeUI.CreateSliderItem("Movement Speed", {0.1, 0.5, 1.0, 2.0, 5.0}, 3)
    local fovItem = NativeUI.CreateSliderItem("FOV (Zoom)", {30, 45, 60, 75, 90}, 3)
    
    local filterNames = {}
    for i=1, #filters do table.insert(filterNames, filters[i][1]) end
    local filterItem = NativeUI.CreateListItem("Visual Filter", filterNames, 1)

    mainMenu:AddItem(toggleCam)
    mainMenu:AddItem(speedItem)
    mainMenu:AddItem(fovItem)
    mainMenu:AddItem(filterItem)

    mainMenu.OnItemSelect = function(sender, item, index)
        if item == toggleCam then
            freecamActive = not freecamActive
            ToggleFreecam(freecamActive)
            menuFocused = false 
        end
    end

    mainMenu.OnListChange = function(sender, item, index)
        if item == filterItem then
            local filterInternal = filters[index][2]
            if filterInternal == "" then ClearTimecycleModifier() else SetTimecycleModifier(filterInternal) end
        end
    end

    mainMenu.OnSliderChange = function(sender, item, index)
        if item == speedItem then
            local speeds = {0.1, 0.5, 1.0, 2.0, 5.0}
            camSpeed = speeds[index]
        elseif item == fovItem then
            local fovs = {30, 45, 60, 75, 90}
            camFov = fovs[index]
            if camHandle then SetCamFov(camHandle, camFov * 1.0) end
        end
    end
end


Citizen.CreateThread(function()
    while NativeUI == nil do Citizen.Wait(100) end
    InitMenu()

    while true do
        Citizen.Wait(0)
        
        if _menuPool:IsAnyMenuOpen() then
            if menuFocused then
                _menuPool:ProcessMenus()
            else
                mainMenu:Draw() 
            end
        end

        if freecamActive and camHandle then
            DrawInstructionalButtons()
            
          
            if IsDisabledControlJustPressed(0, 192) or IsControlJustPressed(0, 192) then
                menuFocused = not menuFocused
                PlaySoundFrontend(-1, "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", false)
            end

            
            DisableControlAction(0, 200, true) 

            if not menuFocused then
                DisableAllControlActions(0)
                EnableControlAction(0, 1, true) 
                EnableControlAction(0, 2, true) 
                EnableControlAction(0, 192, true) 
                EnableControlAction(0, 177, true) 

              
                local mouseX = GetControlNormal(1, 1) * -8.0
                local mouseY = GetControlNormal(1, 2) * -8.0
                local currentRot = GetCamRot(camHandle, 2)
                SetCamRot(camHandle, currentRot.x + mouseY, 0.0, currentRot.z + mouseX, 2)

              
                local rot = GetCamRot(camHandle, 2)
                local forward, right = GetDirectionVectors(rot)
                local pos = GetCamCoord(camHandle)
                
                local actualSpeed = camSpeed
                if IsDisabledControlPressed(0, 21) then actualSpeed = camSpeed * 3.0 end

                if IsDisabledControlPressed(0, 32) then pos = pos + (forward * actualSpeed) end
                if IsDisabledControlPressed(0, 33) then pos = pos - (forward * actualSpeed) end
                if IsDisabledControlPressed(0, 34) then pos = pos - (right * actualSpeed) end
                if IsDisabledControlPressed(0, 35) then pos = pos + (right * actualSpeed) end
                if IsDisabledControlPressed(0, 22) then pos = pos + (vector3(0, 0, 1) * actualSpeed) end 
                if IsDisabledControlPressed(0, 36) then pos = pos - (vector3(0, 0, 1) * actualSpeed) end 
                
                SetCamCoord(camHandle, pos.x, pos.y, pos.z)
            end

            if IsDisabledControlJustPressed(0, 177) then
                freecamActive = false
                ToggleFreecam(false)
                if mainMenu:Visible() then mainMenu:Visible(false) end
            end
        end
    end
end)


function ToggleFreecam(status)
    local p = PlayerPedId()
    if status then
        local pos = GetEntityCoords(p)
        camHandle = CreateCam("DEFAULT_SCRIPTED_CAMERA", true)
        SetCamCoord(camHandle, pos.x, pos.y, pos.z + 2.0)
        SetCamRot(camHandle, 0.0, 0.0, GetEntityHeading(p), 2)
        SetCamFov(camHandle, camFov)
        RenderScriptCams(true, true, 500, true, true)
        FreezeEntityPosition(p, true)
        DisplayRadar(false)
    else
        RenderScriptCams(false, true, 500, true, true)
        DestroyCam(camHandle, false)
        FreezeEntityPosition(p, false)
        DisplayRadar(true)
        ClearTimecycleModifier()
        camHandle = nil
    end
end

function GetDirectionVectors(rotation)
    local z = math.rad(rotation.z)
    local x = math.rad(rotation.x)
    local num = math.abs(math.cos(x))
    return vector3(-math.sin(z) * num, math.cos(z) * num, math.sin(x)), vector3(math.cos(z), math.sin(z), 0)
end

function DrawInstructionalButtons()
    local scaleform = RequestScaleformMovie("INSTRUCTIONAL_BUTTONS")
    if HasScaleformMovieLoaded(scaleform) then
        PushScaleformMovieFunction(scaleform, "CLEAR_ALL")
        PopScaleformMovieFunctionVoid()
        PushScaleformMovieFunction(scaleform, "SET_DATA_SLOT")
        PushScaleformMovieFunctionParameterInt(0)
        PushScaleformMovieFunctionParameterString("~INPUT_FRONTEND_PAUSE_ALTERNATE~")
        PushScaleformMovieFunctionParameterString("Exit")
        PopScaleformMovieFunctionVoid()
        PushScaleformMovieFunction(scaleform, "SET_DATA_SLOT")
        PushScaleformMovieFunctionParameterInt(1)
        PushScaleformMovieFunctionParameterString("~INPUT_DUALSHOCK_SHARE~")
        PushScaleformMovieFunctionParameterString(menuFocused and "Fly Mode" or "Menu Mode")
        PopScaleformMovieFunctionVoid()
        PushScaleformMovieFunction(scaleform, "DRAW_INSTRUCTIONAL_BUTTONS")
        PopScaleformMovieFunctionVoid()
        DrawScaleformMovieFullscreen(scaleform, 255, 255, 255, 255, 0)
    end
end