Config = {}

-- Key to toggle megaphone (Default: 199 is 'P')
Config.ToggleKey = 199 
Config.MegaphoneRange = 40.0 -- Distance in meters

Config.AllowedVehicles = {
    'police',
    'police2',
    'police3',
    'policeb',
    'firetruk',
    'ambulance'
}

Config.Filters = {
    ["low"] = 500.0,  
    ["high"] = 3000.0 
}