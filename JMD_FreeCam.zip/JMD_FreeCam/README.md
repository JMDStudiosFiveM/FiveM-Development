Thank you for downloading and using my FreeCam Script
It took a good amount of time and coding to get it fully functional and to work the way i wanted it to,
expect updates to your CFX Portal later on for feature updates and even more things to come
_______________________________________________________________________________________________________
INSTALLATION 

To install make sure you have already downloaded and installed NativeUI https://github.com/Guad/NativeUI/releases
Unzip JMD_FreeCam and insert it into your servers resources
Edit your Server.CFG to ensure JDM_FreeCam to make sure everything functions properly your Server CFG should look like this 

ensure NativeUI
ensure JMD_FreeCam

________________________________________________________________________________________________________
Discord coming soon check out my GitHub for the time being https://github.com/JonathanS22/FiveM-Development