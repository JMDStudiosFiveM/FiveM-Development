local isMegaphoneOn = false
local megaphoneSubmix = nil

function CreateMegaphoneSubmix()
    megaphoneSubmix = CreateAudioSubmix("Megaphone")   
    local lowFreq = (Config and Config.Filters) and Config.Filters["low"] or 300.0
    local hiFreq = (Config and Config.Filters) and Config.Filters["high"] or 5000.0
    SetAudioSubmixEffectRadioFx(megaphoneSubmix, 0)
    SetAudioSubmixEffectParamInt(megaphoneSubmix, 0, `default`, 1)
    SetAudioSubmixEffectParamFloat(megaphoneSubmix, 0, `freq_low`, lowFreq)
    SetAudioSubmixEffectParamFloat(megaphoneSubmix, 0, `freq_hi`, hiFreq)
    AddAudioSubmixOutput(megaphoneSubmix, 0)
end


function IsVehicleAllowed(modelHash)
    if not Config or not Config.AllowedVehicles then 
        return false 
    end
    for _, name in ipairs(Config.AllowedVehicles) do
        if modelHash == GetHashKey(name) then 
            return true 
        end
    end
    return false
end


CreateThread(function()
    CreateMegaphoneSubmix()
end)