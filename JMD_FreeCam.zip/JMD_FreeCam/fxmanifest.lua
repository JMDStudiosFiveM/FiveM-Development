fx_version 'cerulean'
game 'gta5'

author 'johns0365'
description 'Custom FreeCam System'
version '1.0.0'


client_scripts {
    '@NativeUI/NativeUI.lua', 
    'client.lua'
}

dependencies {
    'NativeUI'
}